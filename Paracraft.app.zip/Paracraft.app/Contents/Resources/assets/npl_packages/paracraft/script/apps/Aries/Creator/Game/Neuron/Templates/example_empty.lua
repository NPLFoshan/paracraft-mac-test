-- 示例文件: NPL script file

-- entry function:
function main(msg)
	-- alert("hello world!")

	-- 如果返回true, 则停止执行背包中所有后面的脚本
	-- return true;
end






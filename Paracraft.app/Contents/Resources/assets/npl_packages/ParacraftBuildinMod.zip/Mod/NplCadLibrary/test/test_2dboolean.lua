rotate(45);
intersection();
scale({2,2});
square():translate(0.5,0.5);
circle();

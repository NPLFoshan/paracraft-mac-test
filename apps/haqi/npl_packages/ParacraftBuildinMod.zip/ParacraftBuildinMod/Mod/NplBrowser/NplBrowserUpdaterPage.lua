--[[
Title: NplBrowserUpdaterPage
Author(s): leio
Date: 2019.3.26
Desc: 
use the lib:
------------------------------------------------------------
NPL.load("(gl)Mod/NplBrowser/NplBrowserUpdaterPage.lua");
local NplBrowserUpdaterPage = commonlib.gettable("Mod.NplBrowser.NplBrowserUpdaterPage");
NplBrowserUpdaterPage.Check()
------------------------------------------------------------
]]
NPL.load("npl_mod/AutoUpdater/AssetsManager.lua");
local AssetsManager = commonlib.gettable("Mod.AutoUpdater.AssetsManager");
NPL.load("(gl)script/ide/timer.lua");
local NplBrowserUpdaterPage = commonlib.inherit(nil,commonlib.gettable("Mod.NplBrowser.NplBrowserUpdaterPage"));
NPL.load("(gl)script/Github/GitReleaseUpdater.lua");
local GitReleaseUpdater = commonlib.gettable("script.Github.GitReleaseUpdater");
NplBrowserUpdaterPage.cef_main_files = {
    "cefclient.exe",
    "NplCefPlugin.dll",
    "libcef.dll",
    "cef.pak",
}
NplBrowserUpdaterPage.checked = false;
NplBrowserUpdaterPage.timer = nil;

local releases_url = "https://api.github.com/repos/tatfook/NplBrowser/releases?per_page=1000";
local cache_folder = "temp/GitReleaseUpdater/NplBrowser";
local dest_folder = "cef3";
local config_file = "Mod/NplBrowser/configs/nplbrowser.xml";
local page;
-- init function. page script fresh is set to false.
function NplBrowserUpdaterPage.OnInit()
	page = document:GetPageCtrl();
end
function NplBrowserUpdaterPage.ShowPage()
	local width, height=512, 300;
	System.App.Commands.Call("File.MCMLWindowFrame", {
		url = "Mod/NplBrowser/NplBrowserUpdaterPage.html", 
		name = "NplBrowserUpdaterPage.ShowPage", 
		isShowTitleBar = false,
		DestroyOnClose = true, 
		style = CommonCtrl.WindowFrame.ContainerStyle,
		zorder = 10,
		allowDrag = true,
		isTopLevel = true,
		directPosition = true,
			align = "_ct",
			x = -width/2,
			y = -height/2,
			width = width,
			height = height,
		cancelShowAnimation = true,
	});
end
function NplBrowserUpdaterPage.UpdateProgressText(text)
	if(page) then
		page:SetValue("progressText", text)
	end
end
-- on line 2
function NplBrowserUpdaterPage.UpdateProgressText2(text)
	if(page) then
		page:SetValue("progressText2", text)
	end
end
function NplBrowserUpdaterPage.Close()
	if(page) then
		page:CloseWindow();
		page = nil;
	end
end
function NplBrowserUpdaterPage.CreateOrGetAssetsManager(id,redist_root,config_file)
    if(not id)then return end

    local a = NplBrowserUpdaterPage.asset_managers;
    if(not a)then

        a = AssetsManager:new();
        local timer;
        if(redist_root and config_file)then
            a:onInit(redist_root,config_file,function(state)
                if(state)then
                    if(state == AssetsManager.State.PREDOWNLOAD_VERSION)then
                        NplBrowserUpdaterPage.UpdateProgressText(L"准备下载版本号");
                    elseif(state == AssetsManager.State.DOWNLOADING_VERSION)then
                        NplBrowserUpdaterPage.UpdateProgressText(L"下载版本号");
                    elseif(state == AssetsManager.State.VERSION_CHECKED)then
                        NplBrowserUpdaterPage.UpdateProgressText(L"检测版本号");
                    elseif(state == AssetsManager.State.VERSION_ERROR)then
                        NplBrowserUpdaterPage.UpdateProgressText(L"版本号错误");
						NplBrowserUpdaterPage.IsUpdating = false
                    elseif(state == AssetsManager.State.PREDOWNLOAD_MANIFEST)then
                        NplBrowserUpdaterPage.UpdateProgressText(L"准备下载文件列表");
                    elseif(state == AssetsManager.State.DOWNLOADING_MANIFEST)then
                        NplBrowserUpdaterPage.UpdateProgressText(L"下载文件列表");
                    elseif(state == AssetsManager.State.MANIFEST_DOWNLOADED)then
                        NplBrowserUpdaterPage.UpdateProgressText(L"下载文件列表完成");
                    elseif(state == AssetsManager.State.MANIFEST_ERROR)then
                        NplBrowserUpdaterPage.UpdateProgressText(L"下载文件列表错误");
						NplBrowserUpdaterPage.IsUpdating = false
                    elseif(state == AssetsManager.State.PREDOWNLOAD_ASSETS)then
                        NplBrowserUpdaterPage.UpdateProgressText(L"准备下载资源文件");

                        local nowTime = 0
                        local lastTime = 0
                        local interval = 100
                        local lastDownloadedSize = 0
                        timer = commonlib.Timer:new({callbackFunc = function(timer)
                            local p = a:getPercent();
                            p = math.floor(p * 100);
                            NplBrowserUpdaterPage.ShowPercent(p);

                            local totalSize = a:getTotalSize()
                            local downloadedSize = a:getDownloadedSize()

                            nowTime = nowTime + interval

                            if downloadedSize > lastDownloadedSize then
                                local downloadSpeed = (downloadedSize - lastDownloadedSize) / ((nowTime - lastTime) / 1000)
                                lastDownloadedSize = downloadedSize
                                lastTime = nowTime

                                local tips = string.format("%.1f/%.1fMB(%.1fKB/S)", downloadedSize / 1024 / 1024, totalSize / 1024 / 1024, downloadSpeed / 1024)
                                NplBrowserUpdaterPage.UpdateProgressText(tips)
                            end
                        end})
                        timer:Change(0, interval)
                    elseif(state == AssetsManager.State.DOWNLOADING_ASSETS)then
                    elseif(state == AssetsManager.State.ASSETS_DOWNLOADED)then
                        NplBrowserUpdaterPage.UpdateProgressText(L"下载资源文件结束");
                        local p = a:getPercent();
                        p = math.floor(p * 100);
                        NplBrowserUpdaterPage.ShowPercent(p);
                        if(timer)then
                             timer:Change();
                             NplBrowserUpdaterPage.LastDownloadedSize = 0
                        end
                        a:apply();
                    elseif(state == AssetsManager.State.ASSETS_ERROR)then
                        NplBrowserUpdaterPage.UpdateProgressText(L"下载资源文件错误");
						NplBrowserUpdaterPage.IsUpdating = false
                    elseif(state == AssetsManager.State.PREUPDATE)then
                        NplBrowserUpdaterPage.UpdateProgressText(L"准备更新");
                    elseif(state == AssetsManager.State.UPDATING)then
                        NplBrowserUpdaterPage.UpdateProgressText(L"更新中");
                    elseif(state == AssetsManager.State.UPDATED)then
                        LOG.std(nil, "debug", "AppLauncher", "更新完成")
                        NplBrowserUpdaterPage.UpdateProgressText(L"更新完成");
						NplBrowserUpdaterPage.IsUpdating = false

                        NplBrowserUpdaterPage.SetChecked(true);

                    elseif(state == AssetsManager.State.FAIL_TO_UPDATED)then
                        NplBrowserUpdaterPage.UpdateProgressText(L"更新错误");
						NplBrowserUpdaterPage.IsUpdating = false
                    end

                    --NplBrowserUpdaterPage.RefreshBtn();
                end
            end, function (dest, cur, total)
                NplBrowserUpdaterPage.OnMovingFileCallback(dest, cur, total)
            end);
        end
        NplBrowserUpdaterPage.asset_managers = a;
    end
    return a;
end
function NplBrowserUpdaterPage.Check(version,callback)
    if(NplBrowserUpdaterPage.checked)then
        if(callback)then
            callback(true);
        end
        return
    end
    if(NplBrowserUpdaterPage.is_opened)then
        return
    end
    NplBrowserUpdaterPage.is_opened = true;
    NplBrowserUpdaterPage.buildin_version = version;
    NplBrowserUpdaterPage.callback = callback;
    NplBrowserUpdaterPage.ShowPage();
    NplBrowserUpdaterPage.OnCheck("browser_asset_manager",dest_folder,config_file)
end
function NplBrowserUpdaterPage.OnCheck(id,folder,config_file)

    if(not id or not folder or not config_file)then return end
    local redist_root = folder .. "/"
	ParaIO.CreateDirectory(redist_root);
    local a = NplBrowserUpdaterPage.CreateOrGetAssetsManager(id,redist_root,config_file);
    if(not a)then return end

    if(NplBrowserUpdaterPage.buildin_version)then
        a:loadLocalVersion()
        local cur_version = a:getCurVersion();
        if(cur_version == NplBrowserUpdaterPage.buildin_version)then
            NplBrowserUpdaterPage.SetChecked(true);
            return
        end
    end
    NplBrowserUpdaterPage.ShowPercent(0);
    a:check(nil,function()
        local cur_version = a:getCurVersion();
        local latest_version = a:getLatestVersion();
        if(a:isNeedUpdate())then
            NplBrowserUpdaterPage.UpdateProgressText(string.format(L"当前版本(%s)        最新版本(%s)",cur_version, latest_version));

            local mytimer = commonlib.Timer:new({callbackFunc = function(timer)
                a:download();
            end})
            mytimer:Change(3000, nil)
        else
            NplBrowserUpdaterPage.SetChecked(true);
        end
    end);
end
function NplBrowserUpdaterPage.ShowPercent()

end

function NplBrowserUpdaterPage.OnMovingFileCallback(dest, cur, total)
    local tips = string.format(L"更新%s (%d/%d)", dest, cur, total)
    NplBrowserUpdaterPage.UpdateProgressText(tips)

    local percent = 100 * cur / total
    NplBrowserUpdaterPage.ShowPercent(percent)
end
function NplBrowserUpdaterPage.SetChecked(v)
    NplBrowserUpdaterPage.checked = v;
    if(NplBrowserUpdaterPage.callback)then
        NplBrowserUpdaterPage.callback(v);
    end
    NplBrowserUpdaterPage.Close();
    NplBrowserUpdaterPage.is_opened = false;

end
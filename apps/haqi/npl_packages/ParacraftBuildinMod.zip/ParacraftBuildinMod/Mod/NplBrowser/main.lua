﻿--[[
Title: NplBrowser
Author(s): leio
Date: 2019.3.22
Desc: 
use the lib:
------------------------------------------------------------
NPL.load("(gl)Mod/NplBrowser/main.lua");
local NplBrowser = commonlib.gettable("Mod.NplBrowser");
------------------------------------------------------------
]]
NPL.load("(gl)Mod/NplBrowser/NplCefBrowserManager.lua");
local NplCefBrowserManager = commonlib.gettable("Mod.NplCefBrowserManager");

local NplBrowser = commonlib.inherit(commonlib.gettable("Mod.ModBase"),commonlib.gettable("Mod.NplBrowser"));

function NplBrowser:ctor()
	
end

-- virtual function get mod name

function NplBrowser:GetName()
	return "NplBrowser"
end

-- virtual function get mod description 

function NplBrowser:GetDesc()
	return "NplBrowser is a plugin in paracraft"
end

function NplBrowser:init()
	LOG.std(nil, "info", "NplBrowser", "plugin initialized");
	-- register a new block item, id < 10512 is internal items, which is not recommended to modify. 
    GameLogic.GetFilters():add_filter("block_types", function(xmlRoot) 
		local blocks = commonlib.XPath.selectNode(xmlRoot, "/blocks/");
		if(blocks) then
			NPL.load("(gl)Mod/NplBrowser/ItemNplBrowser.lua");
			blocks[#blocks+1] = {name="block", attr={ name="NplBrowser",
				id = 10515, item_class="ItemNplBrowser", text=L"npl browser",
				icon = "Mod/NplBrowser/textures/browser.png",
			}}
            LOG.std(nil, "info", "NplBrowser", "NplBrowser  is registered");
		end
		return xmlRoot;
	end)
    -- add block to category list to be displayed in builder window (E key)
	GameLogic.GetFilters():add_filter("block_list", function(xmlRoot) 
		for node in commonlib.XPath.eachNode(xmlRoot, "/blocklist/category") do
			if(node.attr.name == "tool") then
				node[#node+1] = {name="block", attr={name="NplBrowser"} };
			end
		end
		return xmlRoot;
	end)
    NPL.load("(gl)Mod/NplBrowser/NplBrowserPlugin.lua");
    local NplBrowserPlugin = commonlib.gettable("Mod.NplBrowser.NplBrowserPlugin");
    NplBrowserPlugin.RegisterUserControl();
end
function NplBrowser:OnLogin()
end
-- called when a new world is loaded. 

function NplBrowser:OnWorldLoad()
end
-- called when a world is unloaded. 

function NplBrowser:OnLeaveWorld()
end

function NplBrowser:OnDestroy()
end



﻿--[[
Title: NplBrowserUpdaterPage
Author(s): leio
Date: 2019.3.26
Desc: 
use the lib:
------------------------------------------------------------
NPL.load("(gl)Mod/NplBrowser/NplBrowserUpdaterPage.lua");
local NplBrowserUpdaterPage = commonlib.gettable("Mod.NplBrowser.NplBrowserUpdaterPage");
NplBrowserUpdaterPage.Check()
------------------------------------------------------------
]]
NPL.load("(gl)script/ide/timer.lua");
local NplBrowserUpdaterPage = commonlib.inherit(nil,commonlib.gettable("Mod.NplBrowser.NplBrowserUpdaterPage"));
NPL.load("(gl)script/Github/GitReleaseUpdater.lua");
local GitReleaseUpdater = commonlib.gettable("script.Github.GitReleaseUpdater");
NplBrowserUpdaterPage.cef_main_files = {
    "cefclient.exe",
    "NplCefPlugin.dll",
    "libcef.dll",
    "cef.pak",
}
NplBrowserUpdaterPage.checked = false;
NplBrowserUpdaterPage.timer = nil;

local releases_url = "https://api.github.com/repos/tatfook/NplBrowser/releases?per_page=1000";
local cache_folder = "temp/GitReleaseUpdater/NplBrowser";
local dest_folder = "cef3/";

local page;
-- init function. page script fresh is set to false.
function NplBrowserUpdaterPage.OnInit()
	page = document:GetPageCtrl();
end
function NplBrowserUpdaterPage.ShowPage()
	local width, height=512, 300;
	System.App.Commands.Call("File.MCMLWindowFrame", {
		url = "Mod/NplBrowser/NplBrowserUpdaterPage.html", 
		name = "NplBrowserUpdaterPage.ShowPage", 
		isShowTitleBar = false,
		DestroyOnClose = true, 
		style = CommonCtrl.WindowFrame.ContainerStyle,
		zorder = 10,
		allowDrag = true,
		isTopLevel = true,
		directPosition = true,
			align = "_ct",
			x = -width/2,
			y = -height/2,
			width = width,
			height = height,
		cancelShowAnimation = true,
	});
end
function NplBrowserUpdaterPage.UpdateProgressText(text)
	if(page) then
		page:SetValue("progressText", text)
	end
end
-- on line 2
function NplBrowserUpdaterPage.UpdateProgressText2(text)
	if(page) then
		page:SetValue("progressText2", text)
	end
end
function NplBrowserUpdaterPage.Close()
	if(page) then
		page:CloseWindow();
		page = nil;
	end
end
function NplBrowserUpdaterPage.Check(version,callback)
    if(NplBrowserUpdaterPage.checked)then
        if(callback)then
            callback(true);
            return
        end
    end
    if(not NplBrowserUpdaterPage.filesExisted())then
        -- force to update
        version = nil;
    end
    NplBrowserUpdaterPage.callback = callback;
    NplBrowserUpdaterPage.ShowPage();
    local git_release_updater = GitReleaseUpdater:new():onInit(releases_url,cache_folder,dest_folder)
    local function event_callback(state)
        if(state == GitReleaseUpdater.State.VERSION_CHECKED)then
            if(git_release_updater:needUpdate())then
                git_release_updater:download()
                NplBrowserUpdaterPage.timer = commonlib.Timer:new({callbackFunc = function(timer)
                    local is_downloaded = git_release_updater:isAllDownloaded();
                    local download_size = git_release_updater:getDownloadedSize()
                    local total_size = git_release_updater:getTotalSize()
                    if(not is_downloaded)then
					    local text = string.format(L"下载中: %d/%dKB", math.floor(download_size/1024), math.floor(total_size/1024));
                        NplBrowserUpdaterPage.UpdateProgressText(text);
                    else
                        NplBrowserUpdaterPage.UpdateProgressText(L"下载完成");
                        NplBrowserUpdaterPage.timer:Change();
                    end
	            end})
	            NplBrowserUpdaterPage.timer:Change(0,200);
            else
                NplBrowserUpdaterPage.SetChecked(true);
            end
        elseif(state == GitReleaseUpdater.State.ASSETS_DOWNLOADED)then
            git_release_updater:decompress()
        elseif(state == GitReleaseUpdater.State.DOWNLOADING_ASSETS)then
        elseif(state == GitReleaseUpdater.State.FAIL_TO_UPDATED)then
            NplBrowserUpdaterPage.UpdateProgressText(L"更新错误");
	        local mytimer = commonlib.Timer:new({callbackFunc = function(timer)
                NplBrowserUpdaterPage.SetChecked(false);
	        end})
	        mytimer:Change(5000)
        elseif(state == GitReleaseUpdater.State.UPDATED)then

          NplBrowserUpdaterPage.SetChecked(true);
        end
    end
    local function moving_file_callback(name,k,len);
        local s = string.format(L"%s(%d/%d)",name,k,len);
        NplBrowserUpdaterPage.UpdateProgressText(L"正在更新");
        NplBrowserUpdaterPage.UpdateProgressText2(s);
    end
    git_release_updater.event_callback = event_callback;
    git_release_updater.moving_file_callback = moving_file_callback;
    git_release_updater:check(version)
    

end
function NplBrowserUpdaterPage.filesExisted()
    for k,v in ipairs(NplBrowserUpdaterPage.cef_main_files) do
        local filename = string.format("%s%s",dest_folder,v);  
        if(not ParaIO.DoesFileExist(filename))then
            return false
        end
    end
    return true;
end
function NplBrowserUpdaterPage.SetChecked(v)
    NplBrowserUpdaterPage.checked = v;
    if(NplBrowserUpdaterPage.callback)then
        NplBrowserUpdaterPage.callback(v);
    end
    if( NplBrowserUpdaterPage.timer)then
         NplBrowserUpdaterPage.timer:Change();
         NplBrowserUpdaterPage.timer = nil;
    end
    NplBrowserUpdaterPage.Close();
end
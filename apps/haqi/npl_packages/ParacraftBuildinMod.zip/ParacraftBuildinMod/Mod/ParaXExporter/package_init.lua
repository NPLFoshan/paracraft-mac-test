
log(NPL.filename().." loaded\n")
-- NPL.load("(gl)script/apps/Aries/Creator/Game/Mod/ModManager.lua");
--local ModManager = commonlib.gettable("Mod.ModManager");
--ModManager:GetLoader():AddSystemModule("ParaXExporter", {displayName = "ParaX 3D模型导出"});